const RELAY_URL = 'wss://relay.moxifymtg.com';

function generateRoomId() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
}

function generateQR() {
  const roomId = generateRoomId();
  const qrData = JSON.stringify({ relay: RELAY_URL, room: roomId });

  const canvas = document.getElementById('qr-canvas');
  if (typeof QRCode !== 'undefined') {
    QRCode.toCanvas(canvas, qrData, {
      width: 180,
      margin: 0,
      color: { dark: '#1a1a2e', light: '#ffffff' },
    });
  }

  // Tell background to connect
  chrome.runtime.sendMessage({
    type: 'connect_relay',
    relayUrl: RELAY_URL,
    roomId: roomId,
  });

  document.getElementById('status').textContent = 'Waiting for connection...';
  document.getElementById('status').className = 'status';
}

// Check if logged in by querying background for token status
chrome.runtime.sendMessage({ type: 'get_status' }, (response) => {
  if (response && response.hasToken) {
    document.getElementById('content').style.display = 'block';
    document.getElementById('not-logged-in').style.display = 'none';
    generateQR();
  } else {
    // Also check cookies
    chrome.cookies.get({ url: 'https://moxfield.com', name: 'logged_in' }, (cookie) => {
      if (cookie && cookie.value === 'true') {
        document.getElementById('content').style.display = 'block';
        document.getElementById('not-logged-in').style.display = 'none';
        generateQR();
      } else {
        document.getElementById('content').style.display = 'none';
        document.getElementById('not-logged-in').style.display = 'block';
      }
    });
  }
});

document.getElementById('new-code-btn').addEventListener('click', generateQR);

// Listen for connection status updates
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'connection_status') {
    const statusEl = document.getElementById('status');
    switch (message.status) {
      case 'connected':
        statusEl.textContent = 'Connected to Moxify app!';
        statusEl.className = 'status connected';
        break;
      case 'disconnected':
        statusEl.textContent = 'Disconnected';
        statusEl.className = 'status error';
        break;
      case 'waiting':
        statusEl.textContent = 'Waiting for connection...';
        statusEl.className = 'status';
        break;
    }
  }
});
