// Moxify Sync - Background Service Worker
// Manages WebSocket relay connection, token interception, and Moxfield API calls

let relaySocket = null;
let authToken = null;
let moxfieldVersion = null;
let keepAlivePort = null;

const EXTENSION_VERSION = 'v10';
console.log('[Moxify Sync] Service worker started', EXTENSION_VERSION);

// Restore auth token from session storage on startup.
// Service workers can be terminated and restarted - session storage survives
// restarts within the same browser session, so the token stays valid.
chrome.storage.session.get(['authToken', 'moxfieldVersion'], (result) => {
  if (result.authToken) {
    authToken = result.authToken;
    console.log('[Moxify Sync] Restored authToken from session storage');
  }
  if (result.moxfieldVersion) {
    moxfieldVersion = result.moxfieldVersion;
  }
});

// --- Keepalive ---
// Manifest V3 service workers get terminated after ~30s of inactivity.
// We use a port connection from the content script to keep the worker alive
// during an active sync session.

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === 'moxify-keepalive') {
    console.log('[Moxify Sync] Keepalive port connected');
    keepAlivePort = port;
    port.onDisconnect.addListener(() => {
      console.log('[Moxify Sync] Keepalive port disconnected');
      keepAlivePort = null;
    });
  }
});

// --- Token & Version Interception ---

// Intercept Moxfield API requests to capture auth token and version header
chrome.webRequest.onBeforeSendHeaders.addListener(
  (details) => {
    let changed = false;
    for (const header of details.requestHeaders) {
      if (header.name.toLowerCase() === 'authorization' && header.value.startsWith('Bearer ')) {
        const newToken = header.value.replace('Bearer ', '');
        if (newToken !== authToken) {
          authToken = newToken;
          changed = true;
        }
      }
      if (header.name.toLowerCase() === 'x-moxfield-version') {
        moxfieldVersion = header.value;
        changed = true;
      }
    }
    // Persist to session storage so token survives service worker restarts
    if (changed) {
      chrome.storage.session.set({ authToken, moxfieldVersion });
    }
  },
  { urls: ['https://api2.moxfield.com/*'] },
  ['requestHeaders', 'extraHeaders']
);

// --- WebSocket Relay Connection ---

function connectRelay(relayUrl, roomId) {
  const url = `${relayUrl}/room/${roomId}`;

  // If already connected to this exact room, do nothing. This prevents a race
  // condition where closing + immediately reopening to the same room causes the
  // relay to see two brief connections and send a spurious 'paired' event.
  if (
    relaySocket &&
    (relaySocket.readyState === WebSocket.OPEN ||
      relaySocket.readyState === WebSocket.CONNECTING) &&
    relaySocket.url === url
  ) {
    console.log('[Moxify Sync] Already connected to room', roomId, '- skipping reconnect');
    return;
  }

  if (relaySocket) {
    relaySocket.close();
  }

  console.log('[Moxify Sync] Connecting to relay:', url);
  relaySocket = new WebSocket(url);

  relaySocket.onopen = () => {
    console.log('[Moxify Sync] WebSocket connected, waiting for pair');
    notifyContentScript({ type: 'connection_status', status: 'waiting' });
  };

  relaySocket.onmessage = (event) => {
    console.log('[Moxify Sync] Received message:', event.data.substring(0, 200));
    try {
      const message = JSON.parse(event.data);
      // Await the async handler and catch any errors to prevent
      // unhandled promise rejections that could kill the service worker
      handleRelayMessage(message).catch(err => {
        console.error('[Moxify Sync] Unhandled error in message handler:', err);
      });
    } catch (err) {
      console.error('[Moxify Sync] Failed to parse message:', err);
    }
  };

  relaySocket.onclose = (event) => {
    console.log('[Moxify Sync] WebSocket closed:', event.code, event.reason);
    notifyContentScript({ type: 'connection_status', status: 'disconnected' });
    relaySocket = null;
  };

  relaySocket.onerror = (event) => {
    console.error('[Moxify Sync] WebSocket error:', event);
    notifyContentScript({ type: 'connection_status', status: 'disconnected' });
  };
}

function sendToRelay(message) {
  if (relaySocket && relaySocket.readyState === WebSocket.OPEN) {
    const data = JSON.stringify(message);
    console.log('[Moxify Sync] Sending:', data.substring(0, 200));
    relaySocket.send(data);
  } else {
    console.warn('[Moxify Sync] Cannot send - WebSocket not open. State:', relaySocket?.readyState);
  }
}

// --- Message Handling ---

async function handleRelayMessage(message) {
  console.log('[Moxify Sync] Handling message type:', message.type);

  switch (message.type) {
    case 'paired':
      notifyContentScript({ type: 'connection_status', status: 'connected' });
      break;

    case 'partner_disconnected':
      notifyContentScript({ type: 'connection_status', status: 'disconnected' });
      break;

    case 'list_request':
      await handleListRequest();
      break;

    case 'export_start':
      await handleExportStart(message);
      break;

    case 'import_data':
      await handleImportData(message);
      break;

    default:
      console.log('[Moxify Sync] Unknown message type:', message.type);
      break;
  }
}

// --- Moxfield API Helpers ---

function getHeaders() {
  const headers = {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
  };
  if (authToken) {
    headers['Authorization'] = `Bearer ${authToken}`;
  }
  if (moxfieldVersion) {
    headers['x-moxfield-version'] = moxfieldVersion;
  }
  return headers;
}

async function moxfieldGet(path) {
  console.log('[Moxify Sync] GET', path);
  const response = await fetch(`https://api2.moxfield.com${path}`, {
    method: 'GET',
    headers: getHeaders(),
    credentials: 'include',
  });
  console.log('[Moxify Sync] GET', path, '->', response.status);
  return response;
}

async function moxfieldPost(path, body) {
  console.log('[Moxify Sync] POST', path);
  const response = await fetch(`https://api2.moxfield.com${path}`, {
    method: 'POST',
    headers: getHeaders(),
    credentials: 'include',
    body: JSON.stringify(body),
  });
  console.log('[Moxify Sync] POST', path, '->', response.status);
  return response;
}

async function moxfieldPut(path, body, extraHeaders = {}) {
  console.log('[Moxify Sync] PUT', path);
  const response = await fetch(`https://api2.moxfield.com${path}`, {
    method: 'PUT',
    headers: { ...getHeaders(), ...extraHeaders },
    credentials: 'include',
    body: JSON.stringify(body),
  });
  console.log('[Moxify Sync] PUT', path, '->', response.status);
  return response;
}

async function moxfieldDelete(path) {
  console.log('[Moxify Sync] DELETE', path);
  const response = await fetch(`https://api2.moxfield.com${path}`, {
    method: 'DELETE',
    headers: getHeaders(),
    credentials: 'include',
  });
  console.log('[Moxify Sync] DELETE', path, '->', response.status);
  return response;
}

// --- Command Handlers ---

async function handleListRequest() {
  console.log('[Moxify Sync] Handling list_request, authToken:', !!authToken);

  if (!authToken) {
    console.warn('[Moxify Sync] No auth token - user must navigate on Moxfield first');
    sendToRelay({
      type: 'error',
      message: 'Not authenticated. Please scroll or click on Moxfield to refresh your session, then try again.',
    });
    return;
  }

  try {
    const [decksRes, bindersRes] = await Promise.all([
      moxfieldGet('/v3/decks'),
      moxfieldGet('/v1/trade-binders'),
    ]);

    const decksData = await decksRes.json();
    const bindersData = await bindersRes.json();

    const items = [];

    for (const deck of (decksData.decks || [])) {
      items.push({
        id: deck.id,
        publicId: deck.publicId,
        name: deck.name,
        type: 'deck',
        format: deck.format,
        cardCount: deck.mainboardCount + deck.sideboardCount,
        folder: deck.folder ? deck.folder.name : null,
      });
    }

    for (const binder of (Array.isArray(bindersData) ? bindersData : [])) {
      items.push({
        id: binder.id,
        publicId: binder.publicId,
        name: binder.name,
        type: 'binder',
        cardCount: null,
      });
    }

    console.log('[Moxify Sync] Sending list_response with', items.length, 'items');
    sendToRelay({ type: 'list_response', items });
  } catch (err) {
    console.error('[Moxify Sync] handleListRequest error:', err);
    sendToRelay({ type: 'error', message: `Failed to fetch list: ${err.message}` });
  }
}

async function handleExportStart(message) {
  const { items } = message;
  const total = items.length;
  console.log('[Moxify Sync] Starting export of', total, 'items');

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    sendToRelay({ type: 'progress', current: i + 1, total, item: item.name });
    notifyContentScript({ type: 'sync_progress', current: i + 1, total, item: item.name });

    try {
      if (item.type === 'deck') {
        await exportDeck(item);
      } else if (item.type === 'binder') {
        await exportBinder(item);
      }
    } catch (err) {
      console.error('[Moxify Sync] Export error for', item.name, ':', err);
      sendToRelay({ type: 'error', message: `Failed to export ${item.name}: ${err.message}` });
    }

    // Rate limiting: 1 second between requests
    if (i < items.length - 1) {
      await delay(1000);
    }
  }
}

async function exportDeck(item) {
  // Fetch the full deck JSON to extract cards directly
  const res = await moxfieldGet(`/v3/decks/all/${item.publicId}`);

  if (!res.ok) {
    const errorText = await res.text();
    console.error('[Moxify Sync] Fetch deck failed:', res.status, errorText.substring(0, 500));
    throw new Error(`Fetch deck failed with status ${res.status}`);
  }

  const deckData = await res.json();
  const text = deckJsonToText(deckData);
  console.log('[Moxify Sync] Exported deck text (' + text.length + ' chars):', text.substring(0, 500));

  sendToRelay({
    type: 'export_data',
    name: item.name,
    itemType: 'deck',
    format: 'text',
    data: text,
    deckFormat: item.format || deckData.format,
    publicId: item.publicId,
    folder: item.folder || null,
  });
}

// Convert Moxfield deck JSON to text format: "1 Card Name (SET) 123"
function deckJsonToText(deckData) {
  const lines = [];
  const boards = deckData.boards || {};

  // Process mainboard first, then sideboard, then other boards
  const boardOrder = ['mainboard', 'commanders', 'companions', 'sideboard', 'considering', 'maybeboard'];

  for (const boardName of boardOrder) {
    const board = boards[boardName];
    if (!board || !board.cards) continue;

    const cardEntries = Object.values(board.cards);
    if (cardEntries.length === 0) continue;

    // Add section header for non-mainboard sections
    if (boardName !== 'mainboard' && lines.length > 0) {
      const headerName = boardName.charAt(0).toUpperCase() + boardName.slice(1);
      lines.push(headerName);
    }

    for (const entry of cardEntries) {
      const card = entry.card;
      if (!card) continue;

      const qty = entry.quantity || 1;
      const name = card.name || 'Unknown';
      const set = (card.set || '').toUpperCase();
      const cn = card.cn || card.collector_number || '';
      const isFoil = entry.finish === 'foil' || entry.isFoil;

      let line = `${qty} ${name}`;
      if (set && cn) {
        line += ` (${set}) ${cn}`;
      }
      if (isFoil) {
        line += ' *F*';
      }
      lines.push(line);
    }
  }

  return lines.join('\n');
}

async function exportBinder(item) {
  console.log('[Moxify Sync] Binder item:', JSON.stringify(item));

  // Moxfield uses /v1/trade-binders/{publicId}/search for binder card data
  const allCards = [];
  let pageNumber = 1;
  let hasMore = true;
  const pageSize = 100;

  while (hasMore) {
    const searchParams = new URLSearchParams({
      pageNumber: pageNumber.toString(),
      pageSize: pageSize.toString(),
      sortType: 'cardName',
      sortDirection: 'ascending',
      q: ' ',
    });

    const res = await moxfieldGet(
      `/v1/trade-binders/${item.publicId}/search?${searchParams}`
    );

    if (!res.ok) {
      const errorText = await res.text();
      console.error('[Moxify Sync] Binder search failed:', res.status, errorText.substring(0, 500));
      throw new Error(`Binder search failed with status ${res.status}`);
    }

    const data = await res.json();
    console.log('[Moxify Sync] Binder search page', pageNumber, 'keys:', Object.keys(data));

    // Extract cards from the response
    const cards = data.data || [];
    if (pageNumber === 1) {
      console.log('[Moxify Sync] Binder total results:', data.totalResults || data.totalCount || 'unknown');
      if (cards.length > 0) {
        console.log('[Moxify Sync] First card preview:', JSON.stringify(cards[0]).substring(0, 500));
      }
    }

    allCards.push(...cards);
    hasMore = cards.length >= pageSize;
    pageNumber++;
  }

  console.log('[Moxify Sync] Fetched', allCards.length, 'binder cards');

  // Convert to CSV format that the Flutter BoxCsvImporter expects
  const csvText = binderCardsToCSV(allCards);
  console.log('[Moxify Sync] Generated binder CSV (' + csvText.length + ' chars):', csvText.substring(0, 500));

  sendToRelay({
    type: 'export_data',
    name: item.name,
    itemType: 'binder',
    format: 'csv',
    data: csvText,
    publicId: item.publicId,
  });
}

// Convert Moxfield binder card JSON to CSV format matching Moxfield's CSV export
function binderCardsToCSV(cards) {
  const headers = ['Count', 'Tradelist Count', 'Name', 'Edition', 'Condition', 'Language', 'Foil', 'Tags', 'Last Modified', 'Collector Number', 'Alter', 'Proxy', 'Purchase Price'];
  const lines = [headers.join(',')];

  for (const entry of cards) {
    const card = entry.card || entry;
    const name = card.name || '';
    // Try all known field name variants from Moxfield API responses
    const set = card.set || card.setCode || card.edition || card.setAbbreviation || '';
    const cn = card.cn || card.collector_number || card.collectorNumber || card.number || card.cardNumber || '';
    const qty = entry.quantity || entry.count || 1;
    const condition = entry.condition || 'Near Mint';
    const language = entry.language || 'English';
    const isFoil = entry.finish === 'foil' || entry.isFoil || false;
    // Skip cards with no name (defensive)
    if (!name) continue;

    const row = [
      qty,
      qty,
      `"${name.replace(/"/g, '""')}"`,
      `"${set}"`,
      `"${condition}"`,
      `"${language}"`,
      isFoil ? '"foil"' : '""',
      '""',
      '""',
      `"${cn}"`,
      '"False"',
      '"False"',
      '""',
    ];
    lines.push(row.join(','));
  }

  return lines.join('\n');
}

async function handleImportData(message) {
  const { name, itemType, format, data, conflictMode, folder } = message;
  console.log('[Moxify Sync] Importing', itemType, ':', name, folder ? `(folder: ${folder})` : '');

  try {
    if (itemType === 'deck') {
      await importDeck(name, data, message.deckFormat || 'standard', conflictMode, folder);
    } else if (itemType === 'binder') {
      await importBinder(name, data, conflictMode);
    }
  } catch (err) {
    console.error('[Moxify Sync] Import error:', err);
    sendToRelay({
      type: 'import_result',
      name,
      success: false,
      importedCount: 0,
      errors: [err.message],
    });
  }
}

async function findOrCreateDeckFolder(folderName) {
  // List existing deck folders
  const listRes = await moxfieldGet('/v1/deck-folders?pageNumber=1&pageSize=1000');
  if (!listRes.ok) {
    console.warn('[Moxify Sync] Could not fetch deck folders, creating deck without folder');
    return null;
  }
  const listData = await listRes.json();
  const folders = listData.data || [];
  const existing = folders.find(f => f.name === folderName);
  if (existing) {
    console.log('[Moxify Sync] Found existing deck folder:', folderName, existing.id);
    return existing.id;
  }

  // Create new folder
  console.log('[Moxify Sync] Creating deck folder:', folderName);
  const createRes = await moxfieldPost('/v1/deck-folders', { name: folderName });
  if (!createRes.ok) {
    console.warn('[Moxify Sync] Could not create deck folder:', folderName);
    return null;
  }
  const newFolder = await createRes.json();
  console.log('[Moxify Sync] Created deck folder:', newFolder.id);
  return newFolder.id;
}

async function importDeck(name, deckText, format, conflictMode, folderName) {
  const parts = deckText.split(/\nSIDEBOARD:\n/i);
  const mainboard = parts[0] || '';
  const sideboard = parts[1] || '';
  const actualName = conflictMode === 'copy' ? `${name} (Moxify)` : name;

  // For override mode, delete the existing deck (if any) so we start fresh
  // instead of creating a duplicate alongside the original.
  if (conflictMode !== 'copy') {
    const existingDecksRes = await moxfieldGet('/v3/decks');
    const existingDecksData = await existingDecksRes.json();
    const existing = (existingDecksData.decks || []).find(d => d.name === actualName);
    if (existing) {
      console.log('[Moxify Sync] Deleting existing deck for override:', existing.publicId);
      await moxfieldDelete(`/v3/decks/${existing.publicId}`);
    }
  }

  // Resolve folder before creating the deck
  let deckFolderId = null;
  if (folderName) {
    deckFolderId = await findOrCreateDeckFolder(folderName);
  }

  const deckPayload = {
    name: actualName,
    format: format,
    visibility: 'private',
    playStyle: 'paperEuros',
    pricingProvider: 'cardmarket',
    usePrefPrintings: true,
  };
  if (deckFolderId) {
    deckPayload.deckFolderId = deckFolderId;
  }

  const createRes = await moxfieldPost('/v3/decks', deckPayload);
  const createData = await safeJson(createRes);

  const decksRes = await moxfieldGet('/v3/decks');
  const decksData = await decksRes.json();
  const newDeck = (decksData.decks || []).find(d => d.name === actualName);

  if (!newDeck) {
    throw new Error('Could not find newly created deck');
  }

  const bulkEditRes = await moxfieldPut(
    `/v3/decks/${newDeck.publicId}/bulk-edit`,
    {
      boards: {
        mainboard: mainboard.trim(),
        sideboard: sideboard.trim(),
        maybeboard: '',
        companions: '',
        attractions: '',
        stickers: '',
        contraptions: '',
        planes: '',
        schemes: '',
        tokens: '',
      },
      playStyle: 'paperEuros',
      pricingProvider: 'cardmarket',
      usePrefPrintings: true,
      ignoreFlavorNames: false,
    },
    {
      'X-Public-Deck-ID': newDeck.publicId,
      'X-Deck-Version': '0',
    }
  );

  const result = await safeJson(bulkEditRes);

  sendToRelay({
    type: 'import_result',
    name,
    success: bulkEditRes.ok && result.isSuccessful !== false,
    importedCount: result.boardSummary?.boardCounts?.mainboard || 0,
    errors: collectBulkEditErrors(result.errors),
  });
}

function collectBulkEditErrors(errors) {
  if (!errors || !errors.boards) return [];
  const allErrors = [];
  for (const board of Object.values(errors.boards)) {
    if (Array.isArray(board)) {
      allErrors.push(...board);
    }
  }
  return allErrors;
}

async function importBinder(name, csvData, conflictMode) {
  const actualName = conflictMode === 'copy' ? `${name} (Moxify)` : name;

  // For override mode, delete the existing binder (if any) so we start fresh
  // instead of appending cards on top of existing ones.
  if (conflictMode !== 'copy') {
    const existingRes = await moxfieldGet('/v1/trade-binders');
    const existingBinders = await existingRes.json();
    const existing = (Array.isArray(existingBinders) ? existingBinders : []).find(b => b.name === actualName);
    if (existing) {
      console.log('[Moxify Sync] Deleting existing binder for override:', existing.id);
      await moxfieldDelete(`/v1/trade-binders/${existing.id}`);
    }
  }

  await moxfieldPost('/v1/trade-binders', {
    name: actualName,
    description: '',
    visibility: 'public',
  });

  const bindersRes = await moxfieldGet('/v1/trade-binders');
  const binders = await bindersRes.json();
  const newBinder = (Array.isArray(binders) ? binders : []).find(b => b.name === actualName);

  if (!newBinder) {
    throw new Error('Could not find newly created binder');
  }

  const formData = new FormData();
  const blob = new Blob([csvData], { type: 'text/csv' });
  formData.append('file', blob, `${name}.csv`);

  const importHeaders = {};
  if (authToken) {
    importHeaders['Authorization'] = `Bearer ${authToken}`;
  }
  if (moxfieldVersion) {
    importHeaders['x-moxfield-version'] = moxfieldVersion;
  }

  const importRes = await fetch(
    `https://api2.moxfield.com/v1/collections/import-file?game=paper&defaultCondition=nearMint&defaultCardLanguageId=LD58x&defaultQuantity=1&tradeBinderId=${newBinder.id}&playStay=paperEuros&format=moxfield`,
    {
      method: 'POST',
      headers: importHeaders,
      credentials: 'include',
      body: formData,
    }
  );

  const result = await safeJson(importRes);
  console.log('[Moxify Sync] Import binder result:', JSON.stringify(result).substring(0, 500));

  sendToRelay({
    type: 'import_result',
    name,
    success: importRes.ok && result.isSuccessful !== false,
    importedCount: result.totalImportedCount || 0,
    errors: result.errors || [],
  });
}

// --- Utilities ---

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Safely read a response body as JSON. Returns {} when the body is empty or
// not valid JSON (e.g. 204 No Content, plain-text error responses).
async function safeJson(response) {
  const text = await response.text();
  if (!text || !text.trim()) return {};
  try {
    return JSON.parse(text);
  } catch (e) {
    console.warn('[Moxify Sync] Non-JSON response body:', text.substring(0, 200));
    return {};
  }
}

function notifyContentScript(message) {
  chrome.tabs.query({ url: 'https://moxfield.com/*' }, (tabs) => {
    for (const tab of tabs) {
      chrome.tabs.sendMessage(tab.id, message).catch(() => {});
    }
  });
}

// --- Message Listener ---

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log('[Moxify Sync] Received chrome message:', message.type);
  switch (message.type) {
    case 'connect_relay':
      connectRelay(message.relayUrl, message.roomId);
      sendResponse({ ok: true });
      break;

    case 'get_status':
      sendResponse({
        connected: relaySocket && relaySocket.readyState === WebSocket.OPEN,
        hasToken: !!authToken,
      });
      break;
  }
  return true;
});
