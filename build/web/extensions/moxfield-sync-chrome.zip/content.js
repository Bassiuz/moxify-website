// Moxify Sync - Content Script
// Injects a Moxify button into Moxfield's navigation and manages the QR code modal

const RELAY_URL = 'wss://moxfield-sync-relay-1027226883911.europe-west1.run.app';
const EXTENSION_VERSION = 'v10';

let isModalOpen = false;
let connectionStatus = 'disconnected'; // disconnected | waiting | connected
let keepAlivePort = null; // Held as a module-level reference to prevent GC
let currentRoomId = null; // Persist room ID until user clicks "New Connection"

// Generate a cryptographically random room ID
function generateRoomId() {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, b => b.toString(16).padStart(2, '0')).join('');
}

// Check if user is logged into Moxfield
function isLoggedIn() {
  // Check for logged-in UI elements (user menu or personal decks link)
  return !!document.querySelector('#mainmenu-user, a[href="/decks/personal"]');
}

// Find the navigation bar where the purple "+" button lives
function findNavButtonArea() {
  // The "+" button has id="mainmenu-new", its parent <li> is inside the nav icon <ul>
  const createButton = document.querySelector('#mainmenu-new');
  if (createButton) {
    // Return the <li> parent so we insert as a sibling
    return createButton.closest('li')?.parentElement;
  }

  // Fallback: the top-right nav icon list
  const navIcons = document.querySelector('ul.navbar-nav.flex-row.align-items-center');
  return navIcons;
}

// Inject the Moxify button into Moxfield's nav
function injectMoxifyButton() {
  if (document.getElementById('moxify-sync-button')) return;
  if (!isLoggedIn()) return;

  const navArea = findNavButtonArea();
  if (!navArea) {
    // Retry after a short delay - page might still be loading
    setTimeout(injectMoxifyButton, 1000);
    return;
  }

  const li = document.createElement('li');
  li.className = 'nav-item';
  li.id = 'moxify-sync-button';

  const button = document.createElement('div');
  button.className = 'moxify-nav-button';
  button.title = 'Moxify Sync';

  const img = document.createElement('img');
  img.src = chrome.runtime.getURL('icons/icon48.png');
  img.alt = 'Moxify';
  button.appendChild(img);

  const statusDot = document.createElement('div');
  statusDot.className = 'moxify-status-dot';
  statusDot.id = 'moxify-status-dot';
  button.appendChild(statusDot);

  button.addEventListener('click', toggleModal);
  li.appendChild(button);

  // Insert before the "+" button's <li>
  const plusLi = document.querySelector('#mainmenu-new')?.closest('li');
  if (plusLi) {
    navArea.insertBefore(li, plusLi);
  } else {
    navArea.insertBefore(li, navArea.firstChild);
  }
}

// Toggle the QR code modal
function toggleModal() {
  if (isModalOpen) {
    closeModal();
  } else {
    openModal();
  }
}

// Open the modal with QR code
function openModal(forceNewRoom = false) {
  if (document.getElementById('moxify-modal-overlay')) return;

  // Reuse existing room if we have one, unless a new room is explicitly requested.
  // This means closing and reopening the modal (e.g. navigating Moxfield) keeps
  // the same QR code and connection alive.
  if (forceNewRoom || !currentRoomId) {
    currentRoomId = generateRoomId();
  }
  const roomId = currentRoomId;

  // Always start in waiting state when opening the modal. This prevents:
  // 1. "New Connection" button flashing (it's shown for 'disconnected' state)
  // 2. Stale 'connected' label appearing from a previous session
  connectionStatus = 'waiting';

  isModalOpen = true;

  const overlay = document.createElement('div');
  overlay.id = 'moxify-modal-overlay';
  overlay.className = 'moxify-modal-overlay';
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal();
  });

  const modal = document.createElement('div');
  modal.className = 'moxify-modal';

  // Build modal DOM using safe element creation (no innerHTML)
  const logoUrl = chrome.runtime.getURL('icons/icon48.png');

  const header = document.createElement('div');
  header.className = 'moxify-modal-header';
  const logo = document.createElement('img');
  logo.src = logoUrl;
  logo.className = 'moxify-modal-logo';
  logo.alt = 'Moxify';
  const title = document.createElement('h2');
  title.textContent = 'Moxify Sync';
  const version = document.createElement('span');
  version.className = 'moxify-version';
  version.textContent = EXTENSION_VERSION;
  header.appendChild(logo);
  header.appendChild(title);
  header.appendChild(version);

  const body = document.createElement('div');
  body.className = 'moxify-modal-body';
  const instructions = document.createElement('p');
  instructions.textContent = 'Scan this QR code with the Moxify app to connect';
  const qrContainer = document.createElement('div');
  qrContainer.className = 'moxify-qr-container';
  const qrCanvas = document.createElement('canvas');
  qrCanvas.id = 'moxify-qr-canvas';
  qrContainer.appendChild(qrCanvas);
  const status = document.createElement('div');
  status.className = 'moxify-status';
  status.id = 'moxify-modal-status';
  status.textContent = 'Waiting for connection...';
  const reconnectBtn = document.createElement('button');
  reconnectBtn.className = 'moxify-reconnect-btn';
  reconnectBtn.id = 'moxify-reconnect-btn';
  reconnectBtn.style.display = 'none';
  reconnectBtn.textContent = 'New Connection';
  const closeBtn = document.createElement('button');
  closeBtn.className = 'moxify-close-btn';
  closeBtn.id = 'moxify-close-btn';
  closeBtn.textContent = 'Close';
  body.appendChild(instructions);
  body.appendChild(qrContainer);
  body.appendChild(status);
  body.appendChild(reconnectBtn);
  body.appendChild(closeBtn);

  modal.appendChild(header);
  modal.appendChild(body);
  overlay.appendChild(modal);
  document.body.appendChild(overlay);

  closeBtn.addEventListener('click', closeModal);
  reconnectBtn.addEventListener('click', () => {
    // "New Connection" clears the current room and generates a fresh one
    currentRoomId = null;
    closeModal();
    setTimeout(() => openModal(true), 100);
  });

  // Generate QR code
  const qrData = JSON.stringify({ relay: RELAY_URL, room: roomId });
  generateQRCode('moxify-qr-canvas', qrData);

  // Open a keepalive port to prevent service worker termination during sync.
  // Store the reference at module level so it is not garbage collected.
  if (!keepAlivePort) {
    try {
      keepAlivePort = chrome.runtime.connect({ name: 'moxify-keepalive' });
      keepAlivePort.onDisconnect.addListener(() => { keepAlivePort = null; });
    } catch (e) {
      console.warn('[Moxify Sync] Could not open keepalive port:', e);
    }
  }

  // Tell background script to connect to the relay
  chrome.runtime.sendMessage({
    type: 'connect_relay',
    relayUrl: RELAY_URL,
    roomId: roomId
  });
}

// Close the modal
function closeModal() {
  const overlay = document.getElementById('moxify-modal-overlay');
  if (overlay) {
    overlay.remove();
  }
  isModalOpen = false;
}

// Update connection status in UI
function updateConnectionStatus(status) {
  connectionStatus = status;

  // Only show the indicator dot when connected (green). Hide it otherwise.
  const statusDot = document.getElementById('moxify-status-dot');
  if (statusDot) {
    statusDot.style.display = status === 'connected' ? 'block' : 'none';
    statusDot.className = 'moxify-status-dot connected';
  }

  const modalStatus = document.getElementById('moxify-modal-status');
  if (modalStatus) {
    switch (status) {
      case 'waiting':
        modalStatus.textContent = 'Waiting for connection...';
        modalStatus.className = 'moxify-status';
        break;
      case 'connected':
        modalStatus.textContent = 'Connected to Moxify app!';
        modalStatus.className = 'moxify-status connected';
        break;
      case 'disconnected':
        modalStatus.textContent = 'Disconnected';
        modalStatus.className = 'moxify-status';
        break;
    }
  }

  // Show/hide the "New Connection" button
  const reconnectBtn = document.getElementById('moxify-reconnect-btn');
  if (reconnectBtn) {
    reconnectBtn.style.display = (status === 'connected' || status === 'disconnected') ? 'block' : 'none';
  }

  // Dim QR code when connected (it's no longer scannable for the same room)
  const qrContainer = document.querySelector('.moxify-qr-container');
  if (qrContainer) {
    qrContainer.style.opacity = status === 'connected' ? '0.3' : '1';
  }
}

// Listen for messages from the background script
chrome.runtime.onMessage.addListener((message) => {
  switch (message.type) {
    case 'connection_status':
      // Ignore 'disconnected' noise that arrives right after opening the modal
      // (caused by the background closing an old socket for a different room).
      // We already reset to 'waiting' in openModal(), so a stale 'disconnected'
      // from the previous socket would only cause a brief button flash.
      if (message.status === 'disconnected' && connectionStatus === 'waiting') {
        break;
      }
      updateConnectionStatus(message.status);
      break;
    case 'sync_progress':
      updateSyncProgress(message);
      break;
  }
});

function updateSyncProgress(message) {
  const modalStatus = document.getElementById('moxify-modal-status');
  if (modalStatus) {
    modalStatus.textContent = `Syncing: ${message.item} (${message.current}/${message.total})`;
  }
}

// Generate QR code using the qrcode library (loaded via manifest)
function generateQRCode(canvasId, data) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  if (typeof QRCode !== 'undefined' && QRCode.toCanvas) {
    QRCode.toCanvas(canvas, data, {
      width: 200,
      margin: 2,
      color: { dark: '#1a1a2e', light: '#ffffff' }
    }, (err) => {
      if (err) console.error('[Moxify Sync] QR code error:', err);
    });
  } else {
    console.error('[Moxify Sync] QRCode library not available');
  }
}

// Try to inject button, called repeatedly by observer
function tryInject() {
  if (document.getElementById('moxify-sync-button')) return;
  if (!isLoggedIn()) return;
  injectMoxifyButton();
}

// Initialize: set up observer immediately, try inject when ready
function init() {
  console.log('[Moxify Sync] Content script loaded');
  tryInject();

  // Watch for SPA navigation and React rendering (Moxfield is a SPA)
  const observer = new MutationObserver(() => {
    tryInject();
  });

  observer.observe(document.body, { childList: true, subtree: true });
}

// Start when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
